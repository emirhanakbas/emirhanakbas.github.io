document.addEventListener("DOMContentLoaded", function() {
    let username = localStorage.getItem("username") || "Guest";
    document.getElementById("username-display").innerText = username;

    if (username !== "Guest") {
        document.getElementById("logout-link").style.display = "inline-block";
        document.getElementById("login-link").style.display = "none";
        document.getElementById("register-link").style.display = "none";
    }
});

document.getElementById("logout-link").addEventListener("click", function() {
    localStorage.removeItem("username");
    window.location.href = "index.html";
});

document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();
    let email = document.getElementById("email").value;
    localStorage.setItem("username", email.split("@")[0]);
    window.location.href = "profile.html";
});

document.getElementById("register-form")?.addEventListener("submit", function(event) {
    event.preventDefault();
    let username = document.getElementById("username").value;
    localStorage.setItem("username", username);
    window.location.href = "profile.html";
});
