<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userCode = $_POST["code"];

    // Security Check: Block PHP/system commands
    if (preg_match('/(shell_exec|exec|system|passthru|eval)/i', $userCode)) {
        echo "Security Error: Unsafe code detected!";
        exit;
    }

    // Save user code to a temporary file
    $tempFile = tempnam(sys_get_temp_dir(), 'usercode') . '.js';
    file_put_contents($tempFile, $userCode);

    // Run the JavaScript code using Node.js
    $output = shell_exec("node " . escapeshellarg($tempFile) . " 2>&1");

    // Delete the temporary file
    unlink($tempFile);

    // Return the output
    echo htmlspecialchars($output, ENT_QUOTES, 'UTF-8');
} else {
    echo "Invalid request!";
}
?>
